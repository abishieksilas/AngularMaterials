import { Component, OnInit } from '@angular/core';
import {NgForm, Validators} from '@angular/forms';
import { FormControl, FormGroup, FormBuilder, Validator } from '@angular/forms';  

@Component({
  selector: 'app-reactiveforms',
  templateUrl: './reactiveforms.component.html',
  styleUrls: ['./reactiveforms.component.css']
})
export class ReactiveformsComponent{

  checkOutForm: FormGroup;
  constructor(private formBuilder: FormBuilder){
    this.checkOutForm = formBuilder.group({
      email : ['', [Validators.required, Validators.email]],
      password : ['', Validators.minLength(5)],
      check : new FormControl()
    });
  }

  onSubmit() {
    console.log(this.checkOutForm);
    console.log(this.checkOutForm.value.password);
  }

   


}
