import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  name : "abi";
  flag : boolean;
  safeURL : any;

  constructor( private _sanitizer: DomSanitizer){
    
 } 

  ngOnInit(): void {
    this.safeURL = this._sanitizer.bypassSecurityTrustResourceUrl("https://www.youtube.com/embed/oljQt5jngN8");
    this.flag=false;
  }

  onSubmit(event: any) {
    // this.playerName=event.target.player.value;
    // return event.target.player.value;
    console.log(event.target.player.value);
    if( event.target.player.value === "keerth"){
      this.flag= true;
    }
    else{
      this.flag=false;
    }
 }


}
