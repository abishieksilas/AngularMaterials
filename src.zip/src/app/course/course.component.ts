import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

  imageUrl="https://media-cdn.tripadvisor.com/media/photo-s/0d/35/b8/20/great-car-great-scenery.jpg";
  title="List of courses demo";
  courses=["course1","course2"];

}
