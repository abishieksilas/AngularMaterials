import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FavoriteComponent } from './favorite/favorite.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AppComponent } from './app.component';
import { ModalComponent } from './modal/modal.component';
import { TableComponent } from './table/table.component';
import { PipesComponent } from './pipes/pipes.component';
import { CourseComponent } from './course/course.component';
import { ReactiveformsComponent } from './reactiveforms/reactiveforms.component';
import { CardsComponent } from './cards/cards.component';
import { TemplateDrivenFormsComponent } from './template-driven-forms/template-driven-forms.component';

const routes: Routes = [
  //{path: '', component:AppComponent},
  //{path:'appcomponent', component:AppComponent},
  
  {path: "", component: CourseComponent},
  {path: 'favourites', component: FavoriteComponent},
  {path: 'modal', component: ModalComponent}, 
  {path: 'table', component: TableComponent},
  {path: 'pipes', component: PipesComponent},
  {path: 'course', component: CourseComponent},
  {path :'templateForms', component: TemplateDrivenFormsComponent},
  {path: 'reactiveForms', component: ReactiveformsComponent},
  {path: 'cards', component: CardsComponent},
  {path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
 }

export const routingComponents=[FavoriteComponent, ModalComponent]
